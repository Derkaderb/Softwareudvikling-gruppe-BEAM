-------------------------HOW TO INSTALL AND USE---------------------------------------------------

Set your directory/path to this folder through the terminal and run the following commands:

> go build OnlineTA.go

> go run OnlineTA.go

Visit localhost:8080/home/BEAM in your browser

--------------------------------------------------------------------------------------------------
If the program doesn't run, try recompiling all fsx-files:
> fsharpc check.fsx
> fsharpc niveau1.fsx
> fsharpc niveau2.fsx

Then rebuild the OnlineTA.go file

> go build OnlineTA.go

--------------------------------PROGRAM OVERVIEW--------------------------------------------------

Niveau1.fsx: Contains the questions/assignments in level 1 and picks 1 of them randomly.

Niveau2.fsx: Contains the questions/assignments in level 2 and picks 1 of them randomly.

Check.fsx: Compares the userinput with the actual answer in Answer.txt.

OnlineTA: Communicates with the fsx-files, HTML-files, text-files and puts it all togehter.

HTML-files: Contains the visuals for the local server.

Text-files: The F#-files changes and stores data in these.

The folders img and resources contains CSS configs and other visuals.

--------------------------------------BEAM 2016---------------------------------------------------