
package main

import (
    "html/template"
    "io/ioutil"
    "net/http"
    "log"
    "os"
    "os/exec"
)

type Page struct {
    Title string
    Body  []byte
}

func (p *Page) save() error {
    filename := "brugersvar" + ".txt"
    return ioutil.WriteFile(filename, p.Body, 0600)
}

func loadPage(title string) (*Page, error) {
    filename := title + ".txt"
    body, err := ioutil.ReadFile(filename)
    if err != nil {
        return nil, err
    }
    return &Page{Title: title, Body: body}, nil
}

func fsharp(fsharpnavn string) {
  //  path, _ := os.Getwd()

    err := exec.Command("mono", fsharpnavn +".exe").Run()

    if err != nil {
        log.Fatal(err)
        os.Exit(1)
    }
}

func renderTemplate(w http.ResponseWriter, tmpl string, p *Page) {
    t, _ := template.ParseFiles(tmpl + ".html")
    t.Execute(w, p)
}

func homeHandler(w http.ResponseWriter, r *http.Request) {
    title := r.URL.Path[len("/home/"):]
    p, err := loadPage(title)
    if err != nil {
        http.Redirect(w, r, "/indexquest/"+title, http.StatusFound)
        return
    }
    renderTemplate(w, "home", p)
}

func indexquestHandler(w http.ResponseWriter, r *http.Request) {
    title := r.URL.Path[len("/indexquest/"):]
    fsharp("newquest")
    p, err := loadPage("question")
    if err != nil {
        p = &Page{Title: title}
    }
    renderTemplate(w, "indexquest", p)
}

func newquestHandler(w http.ResponseWriter, r *http.Request) {
    title := r.URL.Path[len("/newquest/"):]
    fsharp("newquest")
    p, err := loadPage("question")
    if err != nil {
        p = &Page{Title: title}
    }
    renderTemplate(w, "newquest", p)
}

func svarHandler(w http.ResponseWriter, r *http.Request) {
    title := r.URL.Path[len("/svar/"):]
    body := r.FormValue("body")
    p := &Page{Title: title, Body: []byte(body)}
    p.save()
    http.Redirect(w, r, "/chek/"+"beam", http.StatusFound)
}

func chekHandler(w http.ResponseWriter, r *http.Request) {
    title := r.URL.Path[len("/chek/"):]
    p, err := loadPage(title)
    if err != nil {
        http.Redirect(w, r, "/indexquest/"+title, http.StatusFound)
        return
    }
    renderTemplate(w, "chek", p)
}

func main() {
    http.HandleFunc("/home/", homeHandler)
    http.HandleFunc("/indexquest/", indexquestHandler)
    http.HandleFunc("/newquest/", newquestHandler)
    http.HandleFunc("/svar/", svarHandler)
    http.HandleFunc("/chek/", chekHandler)
    http.ListenAndServe(":8080", nil)
}