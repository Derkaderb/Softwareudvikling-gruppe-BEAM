
package main

import (
    "html/template"
    "io/ioutil"
    "net/http"
    "log"
    "os"
    "os/exec"
)

type Page struct {
    Title string
    Body  []byte
}



func (p *Page) save() error {
    filename := "brugersvar" + ".txt"
    return ioutil.WriteFile(filename, p.Body, 0600)
}

func loadPage(title string) (*Page, error) {
    filename := title + ".txt"
    body, err := ioutil.ReadFile(filename)
    if err != nil {
        return nil, err
    }
    return &Page{Title: title, Body: body}, nil
}

func fsharp(fsharpnavn string) {

    err := exec.Command("mono", fsharpnavn +".exe").Run()

    if err != nil {
        log.Fatal(err)
        os.Exit(1)
    }
}

func renderTemplate(w http.ResponseWriter, tmpl string, p *Page) {
    t, _ := template.ParseFiles(tmpl + ".html")
    t.Execute(w, p)
}

func homeHandler(w http.ResponseWriter, r *http.Request) {
    title := r.URL.Path[len("/home/"):]
    p, err := loadPage(title)
    if err != nil {
        http.Redirect(w, r, "/niveau1/"+title, http.StatusFound)
        return
    }
    renderTemplate(w, "home", p)
    
}

func aboutHandler(w http.ResponseWriter, r *http.Request) {
    title := r.URL.Path[len("/about/"):]
    p, err := loadPage("about")
    if err != nil {
        p = &Page{Title: title}
    }
    renderTemplate(w, "about", p)    
}

func niveau1Handler(w http.ResponseWriter, r *http.Request) {
    title := r.URL.Path[len("/niveau1/"):]
    fsharp("niveau1")
    p, err := loadPage("question")
    if err != nil {
        p = &Page{Title: title}
    }
    renderTemplate(w, "niveau1", p)
}

func niveau2Handler(w http.ResponseWriter, r *http.Request) {
    title := r.URL.Path[len("/niveau2/"):]
    fsharp("niveau2")
    p, err := loadPage("question")
    if err != nil {
        p = &Page{Title: title}
    }
    renderTemplate(w, "niveau2", p)
}

func svar1Handler(w http.ResponseWriter, r *http.Request) {
    title := r.URL.Path[len("/svar/"):]
    body := r.FormValue("body")
    p := &Page{Title: title, Body: []byte(body)}
    p.save()
    http.Redirect(w, r, "/chek1/"+"beam", http.StatusFound)
}

func chek1Handler(w http.ResponseWriter, r *http.Request) {
    title := r.URL.Path[len("/chek1/"):]
        fsharp("chek")
    p, err := loadPage("chek")
    if err != nil {
        http.Redirect(w, r, "/niveau1/"+title, http.StatusFound)
        return
    }
    renderTemplate(w, "chek1", p)
}

func svar2Handler(w http.ResponseWriter, r *http.Request) {
    title := r.URL.Path[len("/svar/"):]
    body := r.FormValue("body")
    p := &Page{Title: title, Body: []byte(body)}
    p.save()
    http.Redirect(w, r, "/chek2/"+"beam", http.StatusFound)
}

func chek2Handler(w http.ResponseWriter, r *http.Request) {
    title := r.URL.Path[len("/chek/"):]
        fsharp("chek")
    p, err := loadPage("chek")
    if err != nil {
        http.Redirect(w, r, "/niveau2/"+title, http.StatusFound)
        return
    }
    renderTemplate(w, "chek2", p)
}

func main() {
    http.Handle("/resources/", http.StripPrefix("/resources/", http.FileServer(http.Dir("resources"))))
    http.Handle("/img/", http.StripPrefix("/img/", http.FileServer(http.Dir("img"))))
    http.HandleFunc("/home/", homeHandler)
    http.HandleFunc("/about/", aboutHandler)
    http.HandleFunc("/niveau1/", niveau1Handler)
    http.HandleFunc("/niveau2/", niveau2Handler)
    http.HandleFunc("/svar1/", svar1Handler)
    http.HandleFunc("/chek1/", chek1Handler)
    http.HandleFunc("/svar2/", svar2Handler)
    http.HandleFunc("/chek2/", chek2Handler)
    http.ListenAndServe(":8080", nil)
}