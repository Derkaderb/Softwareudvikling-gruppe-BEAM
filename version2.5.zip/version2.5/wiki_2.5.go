
package main

import (
    "html/template"
    "io/ioutil"
    "net/http"
    "log"
    "os"
    "os/exec"
)

type Page struct {
    Title string
    Body  []byte
    Tip   []byte
}



func (p *Page) save() error {
    filename := "UserInput" + ".txt"
    return ioutil.WriteFile(filename, p.Body, 0600)
}

func loadPage(title string) (*Page, error) {
    filename := title + ".txt"
    body, err := ioutil.ReadFile(filename)
    if err != nil {
        return nil, err
    }
    return &Page{Title: title, Body: body}, nil
}


func fsharp(fsharpnavn string) {

    err := exec.Command("mono", fsharpnavn +".exe").Run()

    if err != nil {
        log.Fatal(err)
        os.Exit(1)
    }
}

func renderTemplate(w http.ResponseWriter, tmpl string, p *Page) {
    t, _ := template.ParseFiles(tmpl + ".html")
    t.Execute(w, p)
}

func homeHandler(w http.ResponseWriter, r *http.Request) {
    title := r.URL.Path[len("/home/"):]
    p, err := loadPage(title)
    if err != nil {
        http.Redirect(w, r, "/niveau1/"+title, http.StatusFound)
        return
    }
    renderTemplate(w, "home", p)
    
}

func aboutHandler(w http.ResponseWriter, r *http.Request) {
    title := r.URL.Path[len("/about/"):]
    p, err := loadPage("about")
    if err != nil {
        p = &Page{Title: title}
    }
    renderTemplate(w, "about", p)    
}

func niveau1Handler(w http.ResponseWriter, r *http.Request) {
    title := r.URL.Path[len("/niveau1/"):]
    fsharp("niveau1")
    p, err := loadPage("question")
    if err != nil {
        p = &Page{Title: title}
    }

    renderTemplate(w, "niveau1", p)
}


func niveau2Handler(w http.ResponseWriter, r *http.Request) {
    title := r.URL.Path[len("/niveau2/"):]
    fsharp("niveau2")
    p, err := loadPage("question")
    if err != nil {
        p = &Page{Title: title}
    }
    renderTemplate(w, "niveau2", p)
}

func Answer1Handler(w http.ResponseWriter, r *http.Request) {
    title := r.URL.Path[len("/Answer/"):]
    body := r.FormValue("body")
    p := &Page{Title: title, Body: []byte(body)}
    p.save()
    http.Redirect(w, r, "/check1/"+"beam", http.StatusFound)
}

func check1Handler(w http.ResponseWriter, r *http.Request) {
    title := r.URL.Path[len("/check1/"):]
        fsharp("check")
    p, err := loadPage("check")
    if err != nil {
        http.Redirect(w, r, "/niveau1/"+title, http.StatusFound)
        return
    }
    renderTemplate(w, "check1", p)
}

func Answer2Handler(w http.ResponseWriter, r *http.Request) {
    title := r.URL.Path[len("/Answer/"):]
    body := r.FormValue("body")
    p := &Page{Title: title, Body: []byte(body)}
    p.save()
    http.Redirect(w, r, "/check2/"+"beam", http.StatusFound)
}

func check2Handler(w http.ResponseWriter, r *http.Request) {
    title := r.URL.Path[len("/check/"):]
        fsharp("check")
    p, err := loadPage("check")
    if err != nil {
        http.Redirect(w, r, "/niveau2/"+title, http.StatusFound)
        return
    }
    renderTemplate(w, "check2", p)
}

func main() {
    http.Handle("/resources/", http.StripPrefix("/resources/", http.FileServer(http.Dir("resources"))))
    http.Handle("/img/", http.StripPrefix("/img/", http.FileServer(http.Dir("img"))))
    http.HandleFunc("/home/", homeHandler)
    http.HandleFunc("/about/", aboutHandler)
    http.HandleFunc("/niveau1/", niveau1Handler)
    http.HandleFunc("/niveau2/", niveau2Handler)
    http.HandleFunc("/Answer1/", Answer1Handler)
    http.HandleFunc("/check1/", check1Handler)
    http.HandleFunc("/Answer2/", Answer2Handler)
    http.HandleFunc("/check2/", check2Handler)
    http.ListenAndServe(":8080", nil)
}